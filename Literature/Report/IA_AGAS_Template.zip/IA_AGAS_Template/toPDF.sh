#remove temp files
# keep only .tex .bib .sty .cls .pl .txt .sh and  the Makefile
# this solves problem of compiling references by kile 
rm ./*.blg
rm ./*.aux
rm ./*.toc
rm ./*.log
rm ./*.bbl
rm ./*.ps
rm ./*.dvi
rm ./*.pdf
rm ./*.lo*

#generate images
rm ./images/*.eps
cd images
./png2eps.sh
cd ..
# generate the pdf file
make





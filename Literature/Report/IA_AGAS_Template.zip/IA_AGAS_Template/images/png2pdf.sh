mogrify -format pdf *.png

#convert *.png -format pdf
mogrify -format eps *.png
#mogrify -format bmp *.png
#mogrify -format pgm *.bmp
#mogrify -format eps *.pgm


#mkbitmap *.bmp -o pgm
#potrace *.pgm -e -o eps


# in case of error: 
#    sudo nano /etc/ImageMagick-6/policy.xml
# change:
#  <policy domain="coder" rights="read|write" pattern="EPS" />
# then use either convert or mogrify, one of them should work

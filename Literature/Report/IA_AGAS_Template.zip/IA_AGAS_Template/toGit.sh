#!/bin/bash    

cp ~/myDrive/PhD/PhDDissertationDraft/* ~/myGitLab/IKAo_Dissertation/PhDDissertation 

cp ~/myDrive/PhD/PhDDissertationDraft/images/*  ~/myGitLab/IKAo_Dissertation/PhDDissertation/images 

cp ~/myDrive/PhD/PhDDissertationDraft/kile/* ~/myGitLab/IKAo_Dissertation/PhDDissertation/.kile 

cd ~/myGitLab/IKAo_Dissertation

git add .
git commit -m "writing update"
git push


#copy to SVN
cp ~/myDrive/PhD/PhDDissertationDraft/* ~/myGitLab/Agas/cochlear/PhDDissertation 

cp ~/myDrive/PhD/PhDDissertationDraft/images/*  ~/myGitLab/Agas/cochlear/PhDDissertation/images 

cp ~/myDrive/PhD/PhDDissertationDraft/kile/* ~/myGitLab/Agas/cochlear/PhDDissertation/.kile 

cd ~/myGitLab/Agas/cochlear

svn add . --force
svn ci -m "writing update"


